var resultado;
var teclaPress;
var oper1;
var oper2;
var operacion;
var vez=0;

addEventListener('load',inicio,false);

function presiona(e){
  teclaPress=this.getAttribute("id");
  document.getElementById(teclaPress).style="Border: 2px solid rgb(153,163,163)";
}

function suelta(e){
  teclaPress=this.getAttribute("id");
  document.getElementById(teclaPress).style="Border: none";
  validar(teclaPress);
  }

function inicio(){
  var clase = document.getElementsByClassName("tecla");
  for (var i = 0; i < clase.length; i++) {
    clase[i].addEventListener('mousedown',presiona,false);
    clase[i].addEventListener('mouseup',suelta,false);
  }
}

function validar(num){
   var display=document.getElementById("display").innerHTML;

   if (num=="sign"){
       num="-";
   }
   if (num=="punto"){
        num=".";
        for (var i=0;i<=display.length; i++){
          if (display[i]=="."){
            num=" ";
          }
        }
     }

   if (display=="0"){
      document.getElementById("display").innerHTML=num;
   }  else{
      if (num=="-" && display!=="0"){
         if (display[0]=="-"){
             var antes=display;
             display=antes.substring(1,9);
             num=" ";
             document.getElementById("display").innerHTML=display.substring(0,9);
         }
      }

     var numeros="0123456789.-";
     for (var i in numeros){
       if (num==numeros[i]){
         if (num=="-"){
           document.getElementById("display").innerHTML=num+display;
           num=" ";
         } else{
           var total=document.getElementById('display').innerHTML;
           if (total.length<8){
              document.getElementById("display").innerHTML=display+num;
              num=" ";
          }
         }
      }
    }
         switch (num){
            case "mas":
               oper1=document.getElementById("display").innerHTML;
               operacion="+";
               vez=0;
               limpiar();
               break;
            case "menos":
               oper1=document.getElementById("display").innerHTML;
               operacion="-";
               vez=0;
               limpiar();
               break;
            case "por":
              oper1=document.getElementById("display").innerHTML;
              operacion="*";
              vez=0;
              limpiar();
              break;
            case "dividido":
              oper1=document.getElementById("display").innerHTML;
              operacion="/";
              vez=0;
              limpiar();
              break;
            case "igual":
              if (vez < 1){
                oper2=document.getElementById("display").innerHTML;
                var res=resolver(oper1,oper2,operacion);
                res=document.getElementById("display").innerHTML;
                res=resultado;
                document.getElementById("display").innerHTML=res;
                vez=vez+1;
              } else {
                var res=document.getElementById("display").innerHTML;
                res=resolver(res,oper2,operacion);
                res=resultado;
                document.getElementById("display").innerHTML=res;
              }
              break;
            case "on":
              vez=0;
              operacion="";
              oper1=0;
              oper2=0;
              document.getElementById("display").innerHTML="0";
              break;
            }
         }
}

function limpiar(){
  oper1=document.getElementById("display").innerHTML;
  document.getElementById("display").innerHTML="";
}

function resolver(o1,o2,uo){
  resultado=0
  switch (uo) {
     case "+":
       resultado=parseFloat(o1) + parseFloat(o2);
       break;
     case "-":
        resultado=parseFloat(o1) - parseFloat(o2);
        break;
     case "*":
        resultado=parseFloat(o1) * parseFloat(o2);
        break;
     case "/":
        resultado=parseFloat(o1) / parseFloat(o2);
        break;
  }
   var ts=resultado.toString();
   if (ts.length>8){
      resultado=ts.substring(0,8);
   } else {
      resultado=ts;
   }
   return resultado;
}
